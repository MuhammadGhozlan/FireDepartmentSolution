﻿using FireTime.Dtos.Employees;

namespace FireTime.Interfaces.Repo_Interfaces
{
    public interface IEmployeeAssignmentRepository
    {       

        Task<List<EmployeeAssignmentResponse>> GetEmployeeAssignments();
        Task<List<EmployeeAssignmentResponse>> GetEmployeeAssignmentsByEmployeeNbr(string roic);
        Task<EmployeeAssignmentResponse> GetEmployeeAssignmentById(string roic, int assignmentId);
        Task<EmployeeAssignmentResponse> CreateEmployeeAssignment(EmployeeAssignmentRequest request);
        Task<EmployeeAssignmentResponse> UpdateEmployeeAssignment(EmployeeAssignmentRequest request, int assignmentId);
        Task<bool> DeleteEmployeeAssignment(string roic, int assignmentId);

    }
}
